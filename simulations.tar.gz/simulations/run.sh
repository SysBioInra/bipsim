#
# !/bin/sh
#
# Usage:
#   ./run.sh <simulation_directory>
#

SRC_PATH=../bipsim-1.0/src
EXE_NAME=bipsim
PARAMS_PATH=input
PARAMS_FILE=params.in
LOG_FILE=log.txt

CURRENT_DIR=`pwd`
BIN=${CURRENT_DIR}/${SRC_PATH}/${EXE_NAME}
cd $1
${BIN} ${PARAMS_PATH}/${PARAMS_FILE} | tee -a ${LOG_FILE}
cd ${CURRENT_DIR}
